package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.sound.sampled.*;

public class GameApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // 메인 프레임 생성
            JFrame frame = new JFrame("Game");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1300, 790);
            frame.setLayout(new BorderLayout());
            frame.setVisible(true);

            // 메인 패널 생성 (UI를 그리는 패널)
            JPanel panel = new JPanel();
            panel.setLayout(null);
            frame.add(panel, BorderLayout.CENTER);

            // 컨트롤 패널 생성 (하단의 볼륨 슬라이더를 포함)
            JPanel controlPanel = new JPanel();
            controlPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
            frame.add(controlPanel, BorderLayout.SOUTH);

            // 볼륨 슬라이더 추가 (볼륨 조절 기능)
            JSlider volumeSlider = new JSlider(0, 100, 50); // 0~100% 사이, 기본값 50%
            volumeSlider.addChangeListener(e -> {
                float volume = volumeSlider.getValue() / 100f; // 슬라이더 값을 0.0~1.0 범위로 변환
                MusicPlayer.getInstance().setVolume(volume); // MusicPlayer의 볼륨 설정
            });
            controlPanel.add(new JLabel("Volume: ")); // 슬라이더 라벨 추가
            controlPanel.add(volumeSlider);

            // Story 클래스 실행, 종료 후 GameStart 실행
            new Story(panel, new Runnable() {
                @Override
                public void run() {
                    SwingUtilities.invokeLater(() -> new GameStart(panel)); // 스토리가 끝나면 GameStart 실행
                }
            });
        });
    }
}

// -------------------- MusicPlayer 클래스 --------------------
class MusicPlayer {
    private static MusicPlayer instance; // 싱글톤 인스턴스
    private Clip clip; // 오디오 클립 객체
    private FloatControl volumeControl; // 볼륨 조절을 위한 컨트롤러

    // 싱글톤 패턴을 위한 private 생성자
    private MusicPlayer() {
    }

    // MusicPlayer의 유일한 인스턴스 반환
    public static MusicPlayer getInstance() {
        if (instance == null) {
            instance = new MusicPlayer();
        }
        return instance;
    }

    // 음악 파일 재생
    public void playMusic(String filePath) {
        stopMusic(); // 기존 음악 중지
        try {
            File musicFile = new File(filePath); // 음악 파일 로드
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(musicFile);
            clip = AudioSystem.getClip();
            clip.open(audioStream); // 오디오 클립 열기
            clip.loop(Clip.LOOP_CONTINUOUSLY); // 반복 재생
            clip.start();

            volumeControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            setVolume(currentVolume); // 현재 볼륨으로 설정
        } catch (Exception e) {
            System.out.println("음악 파일을 재생할 수 없습니다: " + filePath);
        }
    }

    // 음악 중지
    public void stopMusic() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
            clip.close();
        }
    }

    private float currentVolume = 0.5f; // 기본 볼륨 (50%)

    // 볼륨 설정
    public void setVolume(float volume) {
        currentVolume = volume;
        if (volumeControl != null) {
            float dB;
            if (volume == 0) {
                dB = volumeControl.getMinimum();
            } else {
                dB = (float) (Math.log10(volume) * 20); // 볼륨 값을 데시벨(dB)로 변환
            }
            volumeControl.setValue(dB);
        }
    }

    // 현재 볼륨 반환
    public float getVolume() {
        return currentVolume;
    }
}

// -------------------- Story 클래스 --------------------
class Story {
    // 스토리 텍스트와 이미지 배열
    private static final String[] sentences = {
            "또 밤 샜다. 내가 천재가 아니란 걸 인정한 시간이었다.",
            "자고 일어나보니 시험 종료 10분 전, 이미 끝난 게임이었다.",
            "내 머릿속엔 단 하나의 생각만 남았다.",
            "학교 건물이 없으면 시험도 없는 거 아닌가?",
            "말도 안 된다고?",
            "시간이 없으면 사람은 이상한 데까지 생각이 닿는다.",
            "그래서 결심했다. 학교 건물, 한 번 부숴볼까?"
    };

    private static final String[] imagePaths = {
            "src/images/story1.png",
            "src/images/story2.png",
            "src/images/story3.png",
            "src/images/story4.png",
            "src/images/story5.png",
            "src/images/story6.png",
            "src/images/story7.png"
    };

    private int index = 0; // 현재 스토리 진행 인덱스
    private JLabel textLabel; // 스토리 텍스트 라벨
    private JLabel storyImageLabel; // 스토리 이미지 라벨
    private JButton nextButton; // 다음 버튼
    private Runnable onStoryEnd; // 스토리가 끝난 후 실행할 동작
    private JPanel panel; // 메인 패널
    private JLabel backgroundLabel; // 스토리 배경 라벨

    public Story(JPanel panel, Runnable onStoryEnd) {
        this.panel = panel;
        this.onStoryEnd = onStoryEnd;

        // 스토리 음악 재생
        MusicPlayer.getInstance().playMusic("src/music/storymusic.wav");

        // 메인 패널 초기화
        panel.removeAll();
        panel.setLayout(null);

        // 배경 라벨 설정
        ImageIcon backgroundIcon = new ImageIcon("src/images/storyBG.png");
        backgroundLabel = new JLabel(backgroundIcon);
        backgroundLabel.setLayout(null);
        backgroundLabel.setBounds(0, 0, 1280, 720);
        panel.add(backgroundLabel);

        // 스토리 이미지 라벨 설정
        storyImageLabel = new JLabel();
        storyImageLabel.setHorizontalAlignment(SwingConstants.CENTER);
        storyImageLabel.setBounds(50, 50, 1100, 400);
        backgroundLabel.add(storyImageLabel);

        // 스토리 텍스트 라벨 설정
        textLabel = new JLabel("", SwingConstants.CENTER);
        textLabel.setBounds(50, 465, 1100, 100); // 텍스트 표시 영역 설정
        textLabel.setForeground(Color.WHITE);
        textLabel.setFont(new Font("맑은 고딕", Font.BOLD, 20)); // '맑은 고딕' 폰트
        backgroundLabel.add(textLabel);

        // 다음 버튼 추가
        nextButton = new JButton("다음");
        nextButton.setBounds(550, 620, 100, 50);
        nextButton.addActionListener(e -> showNextContent());
        backgroundLabel.add(nextButton);

        showNextContent(); // 첫 번째 내용 표시

        panel.repaint();
        panel.revalidate();
    }

    private void showNextContent() {
        if (index < sentences.length) {
            // 현재 인덱스에 해당하는 텍스트와 이미지 표시
            textLabel.setText(sentences[index]);
            ImageIcon storyImage = new ImageIcon(imagePaths[index]);
            storyImageLabel.setIcon(storyImage);
            index++;
        } else {
            // 스토리 종료 처리
            nextButton.setEnabled(false);
            MusicPlayer.getInstance().stopMusic(); // 음악 정지
            panel.removeAll(); // 패널 내용 지우기
            panel.repaint();
            onStoryEnd.run(); // GameStart 실행
        }
    }
}

//-------------------- GameStart 클래스 --------------------
//게임 시작 화면 및 캐릭터 선택 기능을 담당
class GameStart {
    private JPanel panel; // 메인 패널
    private JLabel char1, char2; // 캐릭터 선택 라벨
    private JButton gameStartButton; // 게임 시작 버튼
    private boolean char1Selected = false, char2Selected = false; // 선택된 캐릭터 상태

    // 생성자: 게임 시작 화면을 초기화
    public GameStart(JPanel panel) {
        this.panel = panel;

        // 게임 시작 음악 재생
        MusicPlayer.getInstance().playMusic("src/music/GameStartmusic.wav");
        setupIntroScreen(); // 인트로 화면 초기화
    }

    // 인트로 화면 구성
    private void setupIntroScreen() {
        panel.removeAll(); // 기존 패널 내용 제거
        panel.setLayout(null);

        // 배경 이미지 추가
        JLabel introLabel = createBackgroundLabel("src/images/intro.png");
        panel.add(introLabel);

        // 배경 클릭 시 캐릭터 선택 화면으로 전환
        introLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    setupCharacterSelectionScreen(); // 캐릭터 선택 화면 호출
                }
            }
        });

        panel.repaint();
        panel.revalidate();
    }

    // 캐릭터 선택 화면 구성
    private void setupCharacterSelectionScreen() {
        panel.removeAll(); // 기존 패널 내용 제거
        panel.setLayout(null);

        // 배경 이미지 추가
        JLabel bgLabel = createBackgroundLabel("src/images/selectBg.png");
        panel.add(bgLabel);

        // 첫 번째 캐릭터 추가
        char1 = createCharacterLabel("src/images/selectCh1.png", 250, 150, 1);
        bgLabel.add(char1);

        // 두 번째 캐릭터 추가
        char2 = createCharacterLabel("src/images/selectCh2.png", 750, 150, 2);
        bgLabel.add(char2);

        // 게임 시작 버튼 추가
        gameStartButton = createStartButton();
        bgLabel.add(gameStartButton);

        panel.repaint();
        panel.revalidate();
    }

    // 캐릭터 선택 처리
    private void selectCharacter(int character) {
        if (character == 1) {
            // 첫 번째 캐릭터 선택
            char1Selected = true;
            char2Selected = false;
            updateCharacterIcons("src/images/selectedCh1.png", "src/images/selectCh2.png");
        } else if (character == 2) {
            // 두 번째 캐릭터 선택
            char1Selected = false;
            char2Selected = true;
            updateCharacterIcons("src/images/selectCh1.png", "src/images/selectedCh2.png");
        }
    }

    // 게임 시작 처리
    private void startGame() {
        if (!char1Selected && !char2Selected) {
            // 캐릭터가 선택되지 않은 경우 경고 메시지 표시
            JOptionPane.showMessageDialog(panel, "캐릭터를 골라주세요", "메시지", JOptionPane.ERROR_MESSAGE);
        } else {
            // 선택된 캐릭터에 따라 게임 시작
            MusicPlayer.getInstance().stopMusic(); // 음악 정지
            JOptionPane.showMessageDialog(panel, "게임 시작!", "메시지", JOptionPane.INFORMATION_MESSAGE);
            // 이후 게임 시작 로직 추가 가능
        }
    }

    // 배경 라벨 생성
    private JLabel createBackgroundLabel(String imagePath) {
        ImageIcon icon = new ImageIcon(imagePath); // 이미지 로드
        Image img = icon.getImage();
        Image scaledImg = img.getScaledInstance(1280, 720, Image.SCALE_SMOOTH); // 크기 조정
        ImageIcon scaledIcon = new ImageIcon(scaledImg); // 조정된 이미지 아이콘 생성
        JLabel label = new JLabel(scaledIcon);
        label.setBounds(0, 0, 1280, 720); // 라벨의 위치와 크기 설정
        label.setLayout(null);
        return label;
    }

    // 캐릭터 라벨 생성
    private JLabel createCharacterLabel(String imagePath, int x, int y, int characterId) {
        ImageIcon icon = new ImageIcon(imagePath); // 캐릭터 이미지 로드
        JLabel label = new JLabel(icon);
        label.setBounds(x, y, icon.getIconWidth(), icon.getIconHeight()); // 위치와 크기 설정

        // 클릭 이벤트 추가 (캐릭터 선택)
        label.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectCharacter(characterId); // 캐릭터 선택
            }
        });

        return label;
    }

    // 게임 시작 버튼 생성
    private JButton createStartButton() {
        ImageIcon icon = new ImageIcon("src/images/GameStartBtn.png"); // 버튼 이미지 로드
        JButton button = new JButton(icon);
        button.setBounds(450, 500, icon.getIconWidth(), icon.getIconHeight()); // 위치와 크기 설정
        button.setBorderPainted(false); // 버튼 테두리 제거
        button.setContentAreaFilled(false); // 버튼 배경 제거
        button.addActionListener(e -> startGame()); // 클릭 이벤트 추가 (게임 시작)
        return button;
    }

    // 선택된 캐릭터의 아이콘 업데이트
    private void updateCharacterIcons(String char1Image, String char2Image) {
        char1.setIcon(new ImageIcon(char1Image)); // 첫 번째 캐릭터 이미지 업데이트
        char2.setIcon(new ImageIcon(char2Image)); // 두 번째 캐릭터 이미지 업데이트
    }
}
