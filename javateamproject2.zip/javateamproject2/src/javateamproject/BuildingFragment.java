package javateamproject;

import javax.sound.sampled.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.*;
import java.net.URL;

public class BuildingFragment {
    private int x, y, size;
    private int speedX, speedY;
    private Color color;
    private boolean isAttacked; 

    public BuildingFragment(int x, int y, int size, int speedX, int speedY, Color color) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.speedX = speedX;
        this.speedY = speedY;
        this.color = color;
        this.isAttacked = false; // 기본적으로 공격을 받지 않음
    }

    public void update() {
        x += speedX;
        y += speedY;
        speedY += 1; // 중력 효과
    }
    
    // 건물이 공격을 받았을 때 호출되는 메서드
    public void attack() {
        if (!isAttacked) { // 공격받지 않은 상태일 때만 실행
            playSound("/sound/building_attack.wav");  // 소리 재생
            isAttacked = true; // 공격 상태로 변경
        }
    }

    // 소리 재생 메서드
    private void playSound(String filePath) {
        try {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(getClass().getResource(filePath));
            Clip clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.err.println("음성 파일 재생 오류: " + e.getMessage());
        }
    }



    public void draw(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, size, size);
    }

    public boolean isOutOfBounds(int width, int height) {
        return x < 0 || x > width || y > height;
    }
    
 
}
