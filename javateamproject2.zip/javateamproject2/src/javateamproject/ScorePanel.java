package javateamproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class ScorePanel extends JPanel {
    private static final long serialVersionUID = 1L;

    public ScorePanel(JFrame parentFrame, int score, Runnable restartGame) {
        setLayout(new BorderLayout());

        // 점수 표시
        JLabel scoreLabel = new JLabel("최종 점수: " + score, SwingConstants.CENTER);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 40));
        add(scoreLabel, BorderLayout.CENTER);

        // 버튼 패널
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());

        // 다시 시작 버튼
        JButton restartButton = new JButton("다시 시작");
        restartButton.setFont(new Font("Arial", Font.BOLD, 20));
        restartButton.addActionListener(e -> {
            restartGame.run(); // 게임 재시작
        });
        buttonPanel.add(restartButton);

        // 종료 버튼
        JButton exitButton = new JButton("종료");
        exitButton.setFont(new Font("Arial", Font.BOLD, 20));
        exitButton.addActionListener((ActionEvent e) -> {
            System.exit(0); // 프로그램 종료
        });
        buttonPanel.add(exitButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }
}
